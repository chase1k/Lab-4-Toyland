package toys;

public class ActionFigure extends Doll{

    public final static int MIN_ENERGY_LEVEL = 1;
    public final static Color HAIR_COLOR = Color.ORANGE;
    public int EnergyLevel;
    public static int pc = 300;
    public Color hairColor;

    protected ActionFigure(String name, int age, String speak) {
        super(pc++, name, HAIR_COLOR, age, speak);
        EnergyLevel = MIN_ENERGY_LEVEL;
        hairColor = HAIR_COLOR;
    }

    public int getEnergyLevel() {
        return EnergyLevel;
    }

    @Override
    protected void specialPlay(int time) {
        super.specialPlay(time);
    }

    @Override
    public String toString() {
        return super.toString();
    }
}
