package toys;

public interface IToy {

    int getProductCode();

    String getName();

    int getHappiness();

    boolean isRetired();

    double getWear();

    void increaseWear(double amt);

    void play(int time);
}
