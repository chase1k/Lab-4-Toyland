package toys;

public class Doll extends Toy{
    public Color hairColor;
    public int age;
    public String speak;

    public static int pc = 200;

    protected Doll(String name, Color color, int age, String speak) {
        super(name, pc++);
        this.age = age;
        this.speak = speak;
    }

    protected Doll(int productCode, String name, Color hairColor, int age, String speak){
        super(name,productCode);
        this.hairColor = hairColor;
        this.age = age;
        this.speak = speak;
    }

    public Color getHairColor() {
        return hairColor;
    }

    public int getAge() {
        return age;
    }

    public String getSpeak() {
        return speak;
    }

    @Override
    protected void specialPlay(int time) {

    }

    @Override
    public String toString() {
        return super.toString();
    }
}
