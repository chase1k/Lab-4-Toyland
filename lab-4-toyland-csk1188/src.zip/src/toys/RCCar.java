package toys;

public class RCCar extends BatteryPowered{

    public final static int STARTING_SPEED = 10;
    public final static int SPEED_INCREASE = 5;
    public static int pc = 400;

    protected RCCar(String name, int numBatteries){
        super(pc++, name, numBatteries);
    }

    public int getSpeed(){
        return 1;
    }

    protected void specialPlay(int time){

    }

    @Override
    public String toString() {
        return super.toString();
    }
}
