package toys;

public abstract class BatteryPowered extends Toy{

    public final static int FULLY_CHARGED = 100;
    public final static int DEPLETED = 0;
    public int numBatteries;
    //public int batteryLevel;
    protected BatteryPowered(int productCode, String name, int numBatteries){
        super(name, productCode);
        this.numBatteries = numBatteries;

    }

    public int getBatteryLevel(){
        return 1;
    }

    public int getNumBatteries() {
        return numBatteries;
    }

    public void useBatteries(int time){

    }

    @Override
    public String toString() {
        return super.toString();
    }
}
