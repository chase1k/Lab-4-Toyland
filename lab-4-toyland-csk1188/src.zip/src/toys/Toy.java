package toys;

public abstract class Toy implements IToy {
    public final static int INITIAL_HAPPINESS = 0;
    public final static int MAX_HAPPINESS = 100;
    public final static double INITIAL_WEAR = 0.0;
    private String name;
    private int productCode;
    private int happiness;
    private boolean retired;
    private double wear;

    protected Toy(String name, int productCode) {
        this.name = name;
        this.productCode = productCode;
        happiness = INITIAL_HAPPINESS;
        wear = INITIAL_WEAR;
        retired = false;

    }

    public int getProductCode() {return productCode;}

    public String getName() {return name;}

    public int getHappiness() {return happiness;}

    public boolean isRetired() {
        return happiness >= MAX_HAPPINESS;
    }

    public double getWear() {return wear;}

    public void increaseWear(double amt) {wear += amt;}

    public void play(int time){
        System.out.println("PLAYING("+time+"): "+this);
        specialPlay(time);
        happiness += time;
        if(happiness > MAX_HAPPINESS){
            System.out.println("RETIRED: "+this);
        }
    }

    protected abstract void specialPlay(int time);// increases happiness

    @Override
    public String toString() {
        return "Toy{PC:"+productCode+", N:"+name+", H:"+happiness+", R:"+isRetired()+", W:"+wear+"}";
    }
}