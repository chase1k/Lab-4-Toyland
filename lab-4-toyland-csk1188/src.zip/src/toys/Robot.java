package toys;

public class Robot extends BatteryPowered{

    public final static int FLY_SPEED = 25;
    public final static int RUN_SPEED = 10;
    public final static int INITIAL_SPEED = 0;
    public static int pc = 500;
    public boolean flying;

    protected Robot(String name, int numBatteries, boolean flying){
        super(pc++, name, numBatteries);
        this.flying = false;

    }

    public boolean isFlying() {
        return flying;
    }

    public int getDistance(){
        return 1;
    }

    protected void specialPlay(int time){

    }

    @Override
    public String toString() {
        return super.toString();
    }
}
