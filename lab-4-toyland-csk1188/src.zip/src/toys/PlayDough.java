package toys;

public class PlayDough extends Toy{

    public final static double WEAR_MULTIPLIER = .05;
    public Color color;
    public static int pc = 100;
    protected PlayDough(String name, Color color){
        super(name, pc++);
        this.color = color;
    }

    public Color getColor() {
        return color; //colour
    }

    /*@Override
    public void play(int time) {
        super.play(time);
    }*/

    @Override
    protected void specialPlay(int time) {
        System.out.println("\tArts and crafting with "+this.color+" "+getName());
        super.increaseWear(time * WEAR_MULTIPLIER);
    }

    @Override
    public String toString() {
        return super.toString()+", PlayDough{C:"+color+"}";
    }
}
